Как собрать APK:
1. Установи Android Studio (бесплатно).
2. File > Open > выбери папку VoiceMod, дождись синхронизации Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Готовый файл: app/build/outputs/apk/debug/app-debug.apk
5. Скинь его на телефон и установи (разреши установку из неизвестных источников).
