Как обновить сборку с телефона:
1. На GitHub: Add file > Upload files, загрузи новый VoiceMod-android-project.zip (с тем же именем, он заменит старый).
2. Commit changes. Сборка запустится сама (вкладка Actions).
3. Новый APK появится в Releases (build-2, build-3 и т.д.).
