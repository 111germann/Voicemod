package com.example.voicemod

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.min

class Voice(val emoji: String, val name: String, val st: Int, val ring: Int, val echoMs: Int, val dist: Float)

val VOICES = listOf(
    Voice("🎤", "Обычный", 0, 0, 0, 0f), Voice("🐻", "Бас", -6, 0, 0, 0f), Voice("🐿️", "Бурундук", 8, 0, 0, 0f),
    Voice("🧒", "Ребёнок", 5, 0, 0, 0f), Voice("🤖", "Робот", -2, 45, 0, 0f), Voice("👽", "Пришелец", 3, 110, 0, 0f),
    Voice("👹", "Монстр", -9, 0, 0, 0.5f), Voice("👺", "Орк", -7, 0, 0, 0.8f), Voice("🕳️", "Пещера", 0, 0, 160, 0f),
    Voice("🚀", "Космос", 2, 0, 320, 0f), Voice("🌑", "Тьма", -12, 0, 90, 0f), Voice("📻", "Радио", 1, 0, 0, 0.4f)
)
val SOUNDS = listOf("📯" to "Горн", "🎺" to "Грусть", "🚨" to "Сирена", "🔫" to "Лазер", "💥" to "Дроп", "👏" to "Хлопки")

class PowerView(c: Context) : View(c) {
    var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sm = 0f
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = min(width, height) * 0.28f
        sm = sm * 0.8f + (if (on) VoiceEngine.level else 0f) * 0.2f
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.06f
        for (i in 3 downTo 1) {
            p.color = Color.parseColor(if (on) "#22E6FF" else "#6B3FD0")
            p.alpha = (60 / i + (if (on) (sm * 300).toInt() else 0)).coerceAtMost(255)
            cv.drawCircle(cx, cy, r * (1f + 0.22f * i) + r * sm * 0.5f, p)
        }
        p.style = Paint.Style.FILL
        if (on) p.shader = SweepGradient(cx, cy, intArrayOf(Color.parseColor("#22E6FF"), Color.parseColor("#FF2BD6"), Color.parseColor("#22E6FF")), null)
        else p.color = Color.parseColor("#2A1659")
        p.alpha = 255
        cv.drawCircle(cx, cy, r, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.1f; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
        cv.drawArc(RectF(cx - r * 0.38f, cy - r * 0.38f, cx + r * 0.38f, cy + r * 0.38f), -60f, 300f, false, p)
        cv.drawLine(cx, cy - r * 0.5f, cx, cy - r * 0.05f, p)
        if (on) postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {
    private val CYAN = Color.parseColor("#22E6FF")
    private val MAG = Color.parseColor("#FF2BD6")
    private lateinit var power: PowerView
    private lateinit var status: TextView
    private lateinit var pitch: TextView
    private lateinit var seek: SeekBar
    private val voiceTiles = mutableListOf<View>()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun style(v: View, active: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            if (active) { setOrientation(GradientDrawable.Orientation.LEFT_RIGHT); setColors(intArrayOf(CYAN, MAG)) }
            else { setColor(Color.parseColor("#241046")); setStroke(dp(1), Color.parseColor("#4B2A8A")) }
        }
    }

    private fun tile(emoji: String, name: String, click: () -> Unit): LinearLayout {
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, dp(86), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnClickListener { click() }
        }
        t.addView(TextView(this).apply { text = emoji; textSize = 26f; gravity = Gravity.CENTER })
        t.addView(TextView(this).apply { text = name; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        style(t, false)
        return t
    }

    private fun grid(parent: LinearLayout, tiles: List<View>, cols: Int) {
        tiles.chunked(cols).forEach { chunk ->
            val row = LinearLayout(this)
            chunk.forEach { row.addView(it) }
            repeat(cols - chunk.size) { row.addView(Space(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }) }
            parent.addView(row)
        }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; setTextColor(CYAN); textSize = 13f; letterSpacing = 0.2f
        typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(22), 0, dp(8))
    }

    private fun pick(i: Int) {
        val v = VOICES[i]
        VoiceEngine.ringHz = v.ring; VoiceEngine.echoMs = v.echoMs; VoiceEngine.dist = v.dist
        seek.progress = v.st + 12
        voiceTiles.forEachIndexed { k, t -> style(t, k == i) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0B0620"); window.navigationBarColor = Color.parseColor("#2A0A4F")
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(34), dp(14), dp(30)) }
        col.addView(TextView(this).apply {
            text = "VOICE MOD"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.12f; gravity = Gravity.CENTER
        })
        power = PowerView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(250)); setOnClickListener { toggle() } }
        col.addView(power)
        status = TextView(this).apply { textSize = 15f; setTextColor(Color.parseColor("#B9A8FF")); gravity = Gravity.CENTER }
        col.addView(status)

        col.addView(label("ГОЛОСА"))
        voiceTiles.addAll(VOICES.mapIndexed { i, v -> tile(v.emoji, v.name) { pick(i) } })
        grid(col, voiceTiles, 3)

        col.addView(label("ТОН"))
        pitch = TextView(this).apply { setTextColor(Color.WHITE); setPadding(dp(4), 0, 0, 0) }
        col.addView(pitch)
        seek = SeekBar(this).apply {
            max = 24; progressTintList = ColorStateList.valueOf(MAG); thumbTintList = ColorStateList.valueOf(CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    VoiceEngine.semitones = p - 12; pitch.text = "полутонов: ${p - 12}"
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        col.addView(seek)

        col.addView(label("ШУМОПОДАВЛЕНИЕ"))
        val nsText = TextView(this).apply { setTextColor(Color.WHITE); setPadding(dp(4), 0, 0, 0); text = "выключено" }
        col.addView(nsText)
        col.addView(SeekBar(this).apply {
            max = 10; progressTintList = ColorStateList.valueOf(MAG); thumbTintList = ColorStateList.valueOf(CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    VoiceEngine.nsLevel = p; nsText.text = if (p == 0) "выключено" else "сила: $p из 10"
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })

        col.addView(label("ЗВУКИ"))
        grid(col, SOUNDS.mapIndexed { i, (e, n) -> tile(e, n) {
            if (VoiceEngine.running) VoiceEngine.play(i) else Toast.makeText(this, "Сначала включи микрофон", Toast.LENGTH_SHORT).show()
        }.also { style(it, false) } }, 3)

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#0B0620"), Color.parseColor("#2A0A4F")))
            addView(col)
        })
        pick(0)
    }

    override fun onResume() { super.onResume(); sync() }

    private fun sync() {
        power.on = VoiceEngine.running; power.invalidate()
        status.text = if (VoiceEngine.running) "Включено. Говори." else "Нажми кнопку, чтобы включить"
    }

    private fun toggle() {
        if (VoiceEngine.running) { stopService(Intent(this, VoiceService::class.java)); power.postDelayed({ sync() }, 300); return }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) go() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        val i = p.indexOf(Manifest.permission.RECORD_AUDIO)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) go()
        else Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_SHORT).show()
    }

    private fun go() { startForegroundService(Intent(this, VoiceService::class.java)); power.postDelayed({ sync() }, 400) }
}
