package com.example.voicemod

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val engine = VoiceEngine()
    private var on = false
    private lateinit var toggle: Button
    private lateinit var seek: SeekBar
    private lateinit var label: TextView
    private lateinit var robot: Switch
    private lateinit var echo: Switch

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "Войс мод"; textSize = 30f })
        root.addView(TextView(this).apply { text = "Надень наушники, иначе будет свист." })

        toggle = Button(this).apply { text = "Включить"; setOnClickListener { onToggle() } }
        root.addView(toggle)

        label = TextView(this).apply { text = "Тон: 0"; setPadding(0, pad, 0, 0) }
        root.addView(label)
        seek = SeekBar(this).apply {
            max = 24; progress = 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    engine.semitones = p - 12
                    label.text = "Тон: ${p - 12}"
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        root.addView(seek)

        val presets = listOf(
            Triple("Обычный", 0, 0), Triple("Бас", -6, 0),
            Triple("Бурундук", 8, 0), Triple("Робот", -2, 1), Triple("Монстр", -9, 0)
        )
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        presets.forEach { (name, st, r) ->
            row.addView(Button(this).apply {
                text = name; textSize = 11f
                setOnClickListener { seek.progress = st + 12; robot.isChecked = r == 1 }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)

        robot = Switch(this).apply {
            text = "Робот"; setOnCheckedChangeListener { _, c -> engine.robot = c }
        }
        echo = Switch(this).apply {
            text = "Эхо"; setOnCheckedChangeListener { _, c -> engine.echo = c }
        }
        root.addView(robot); root.addView(echo)
        setContentView(root)
    }

    private fun onToggle() {
        if (on) { stopEngine(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        } else startEngine()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (r.firstOrNull() == PackageManager.PERMISSION_GRANTED) startEngine()
        else Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_SHORT).show()
    }

    private fun startEngine() { engine.start(); on = true; toggle.text = "Выключить" }
    private fun stopEngine() { engine.stop(); on = false; toggle.text = "Включить" }
    override fun onStop() { super.onStop(); if (on) stopEngine() }
}
