package com.example.voicemod

import android.annotation.SuppressLint
import android.media.*
import android.media.audiofx.NoiseSuppressor
import kotlin.math.*
import kotlin.random.Random

object VoiceEngine {
    const val SR = 44100
    @Volatile var semitones = 0
    @Volatile var ringHz = 0
    @Volatile var echoMs = 0
    @Volatile var dist = 0f
    @Volatile var level = 0f
    /** Шумоподавление: 0 = выкл, 1..10 = порог шумового гейта. */
    @Volatile var nsLevel = 0
    @Volatile var running = false
        private set
    @Volatile private var sfx: FloatArray? = null
    @Volatile private var sfxPos = 0
    private var thread: Thread? = null

    fun start() { if (running) return; running = true; thread = Thread { loop() }.also { it.start() } }
    fun stop() { running = false; thread?.join(); thread = null; level = 0f }
    fun play(id: Int) { val s = gen(id); sfxPos = 0; sfx = s }

    /** Синтез звуковых эффектов, файлы не нужны. */
    private fun gen(id: Int): FloatArray {
        val dur = when (id) { 0 -> 1.2f; 1 -> 1.5f; 2 -> 2f; 3 -> 0.5f; 4 -> 1f; else -> 2f }
        val out = FloatArray((dur * SR).toInt())
        var ph = 0.0
        val rnd = Random(1)
        for (i in out.indices) {
            val t = i / SR.toFloat()
            val fade = min(1f, (dur - t) * 5f)
            out[i] = when (id) {
                0 -> { var s = 0f; for (f in floatArrayOf(415f, 523f, 622f)) s += 2 * ((f * t) % 1f) - 1; s / 3 * min(1f, t * 30f) * fade * 0.5f }
                1 -> { val f = when { t < 0.3f -> 311f; t < 0.6f -> 293f; t < 0.9f -> 277f; else -> 233f * (1f - 0.04f * sin(2 * PI * 6 * t).toFloat()) }
                    (2 * ((f * t) % 1f) - 1) * 0.4f * fade }
                2 -> { val f = 700f + 350f * sin(2 * PI * 1.2 * t).toFloat(); ph += 2 * PI * f / SR; (sin(ph).toFloat() + 0.4f * sin(2 * ph).toFloat()) * 0.35f * fade }
                3 -> { val f = 200f + 1800f * exp(-8f * t); ph += 2 * PI * f / SR; sin(ph).toFloat() * 0.6f * exp(-3f * t) }
                4 -> { val f = 40f + 150f * exp(-5f * t); ph += 2 * PI * f / SR; sin(ph).toFloat() * 0.9f * exp(-2.5f * t) }
                else -> (rnd.nextFloat() * 2 - 1) * 0.4f * (0.5f + 0.5f * abs(sin(t * 47f))) * min(1f, (dur - t) * 3f)
            }
        }
        return out
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val frames = 512
        val inBuf = max(AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), frames * 4)
        val outBuf = max(AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT), frames * 4)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, inBuf)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(outBuf)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()

        val w = 2048; val n = 32768
        val buf = FloatArray(n); var wp = 0; var ph = 0f
        val ed = FloatArray(SR); var ep = 0
        var t = 0.0
        // Аппаратное шумоподавление Android (если есть на устройстве) + свой фильтр и гейт
        val ns: NoiseSuppressor? = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId) else null
        var nsOn = false
        var hpX = 0f; var hpY = 0f; var env = 0f; var gate = 1f
        val pcm = ShortArray(frames)
        rec.startRecording(); track.play()
        while (running) {
            val read = rec.read(pcm, 0, frames)
            if (read <= 0) continue
            val ratio = 2.0.pow(semitones / 12.0).toFloat()
            val nl = nsLevel
            if ((nl > 0) != nsOn) { nsOn = nl > 0; ns?.setEnabled(nsOn) }
            val thr = nl * 0.004f
            val ring = ringHz; val dl = (echoMs * SR / 1000).coerceIn(0, ed.size - 1); val ds = dist
            var pk = 0f
            for (i in 0 until read) {
                var x = pcm[i] / 32768f
                pk = max(pk, abs(x))
                if (nl > 0) {
                    // фильтр верхних частот убирает гул и ветер (ниже ~100 Гц)
                    val y = 0.98f * (hpY + x - hpX); hpX = x; hpY = y; x = y
                    // шумовой гейт: тихие участки плавно приглушаются
                    val a = abs(x)
                    env += (a - env) * (if (a > env) 0.2f else 0.0008f)
                    val target = ((env - thr * 0.5f) / (thr * 0.5f)).coerceIn(0f, 1f)
                    gate += (target - gate) * (if (target > gate) 0.05f else 0.0008f)
                    x *= gate
                }
                buf[wp] = x
                var o = 0f
                for (k in 0..1) {
                    val p = (ph + k * 0.5f) % 1f
                    var rp = wp - (p * w + 2); if (rp < 0) rp += n
                    val i0 = rp.toInt(); val f = rp - i0
                    val s = buf[i0] * (1 - f) + buf[(i0 + 1) % n] * f
                    val sn = sin(PI * p).toFloat(); o += s * sn * sn
                }
                wp = (wp + 1) % n
                ph += (1 - ratio) / w; ph -= floor(ph)

                if (ring > 0) { o *= sin(2 * PI * ring * t).toFloat(); t += 1.0 / SR }
                if (ds > 0f) o = tanh(o * (1f + ds * 8f)) * 0.8f
                if (dl > 0) {
                    val e = ed[(ep - dl + ed.size) % ed.size]
                    ed[ep] = o + e * 0.5f; ep = (ep + 1) % ed.size
                    o += e * 0.5f
                }
                val s = sfx
                if (s != null) { if (sfxPos < s.size) o += s[sfxPos++] else sfx = null }
                pcm[i] = (o.coerceIn(-1f, 1f) * 32767).toInt().toShort()
            }
            level = min(1f, pk * 2f)
            track.write(pcm, 0, read)
        }
        ns?.release()
        rec.stop(); rec.release(); track.stop(); track.release()
    }
}
