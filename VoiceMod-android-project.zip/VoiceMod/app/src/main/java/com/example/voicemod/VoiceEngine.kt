package com.example.voicemod

import android.annotation.SuppressLint
import android.media.*
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/** Микрофон -> сдвиг тона -> робот/эхо -> динамик/наушники. */
class VoiceEngine {
    @Volatile var semitones = 0
    @Volatile var robot = false
    @Volatile var echo = false
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread { loop() }.also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join()
        thread = null
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val sr = 44100
        val frames = 512
        val inBuf = max(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), frames * 4)
        val outBuf = max(AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT), frames * 4)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, inBuf)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(sr)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(outBuf)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()

        // Сдвиг тона: две линии задержки с плавным перекрытием
        val w = 2048
        val n = 32768
        val buf = FloatArray(n)
        var wp = 0
        var ph = 0f
        // Эхо
        val ed = FloatArray(sr)
        val delay = (sr * 0.28f).toInt()
        var ep = 0
        // Робот
        var t = 0.0

        val pcm = ShortArray(frames)
        rec.startRecording()
        track.play()
        while (running) {
            val read = rec.read(pcm, 0, frames)
            if (read <= 0) continue
            val ratio = 2.0.pow(semitones / 12.0).toFloat()
            val robotOn = robot
            val echoOn = echo
            for (i in 0 until read) {
                buf[wp] = pcm[i] / 32768f
                var o = 0f
                for (k in 0..1) {
                    val p = (ph + k * 0.5f) % 1f
                    var rp = wp - (p * w + 2)
                    if (rp < 0) rp += n
                    val i0 = rp.toInt()
                    val f = rp - i0
                    val s = buf[i0] * (1 - f) + buf[(i0 + 1) % n] * f
                    val sn = sin(PI * p).toFloat()
                    o += s * sn * sn
                }
                wp = (wp + 1) % n
                ph += (1 - ratio) / w
                ph -= kotlin.math.floor(ph)

                if (robotOn) {
                    o *= sin(2 * PI * 45.0 * t).toFloat()
                    t += 1.0 / sr
                }
                val e = ed[(ep - delay + ed.size) % ed.size]
                ed[ep] = o + e * 0.4f
                ep = (ep + 1) % ed.size
                if (echoOn) o += e * 0.45f

                pcm[i] = (o.coerceIn(-1f, 1f) * 32767).toInt().toShort()
            }
            track.write(pcm, 0, read)
        }
        rec.stop(); rec.release()
        track.stop(); track.release()
    }
}
