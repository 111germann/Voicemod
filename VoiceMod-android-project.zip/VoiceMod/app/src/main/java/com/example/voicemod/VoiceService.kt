package com.example.voicemod

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Держит микрофон включённым, даже когда приложение свёрнуто. */
class VoiceService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vm", "Войс мод", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "vm")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Войс мод работает")
            .setContentText("Нажми, чтобы открыть")
            .setContentIntent(open).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        VoiceEngine.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() { VoiceEngine.stop(); super.onDestroy() }
}
